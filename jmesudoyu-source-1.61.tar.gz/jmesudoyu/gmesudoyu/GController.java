/*
 * Copyright 2005-2008 David Hall (gringer)
 *
 *  This file is part of JMeSudoYu, a Java sudoku Solver/Puzzle generator
 *  with an emphasis on easily portable code for j2me-capable cellphones.
 *
 *  JMeSudoYu is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  JMeSudoYu is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with JMeSudoYu.  If not, see <http://www.gnu.org/licenses/>.
 */
package gmesudoyu;

import base.Board;
import base.Commander;
import base.Controller;
import base.GlobalVar;
import base.SaveResource;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Controller class for the graphical (Java) port. This class manages input and
 * non-graphical (or non-board) output. It has a fairly strong tie-in with the
 * Commander class.
 * 
 * @author gringer
 * 
 */
public class GController implements Controller, KeyListener, MouseListener,
        ActionListener, HierarchyBoundsListener {
    static final long serialVersionUID = 1;

    Board gameBoard;
    Commander gameCommand;
    GPainter gamePainter;
    JFrame program;
    JFileChooser fileSelect;
    boolean started;

    /**
     * Initial setup of the program, including frame, etc
     */
    public GController(Board tBoard) {
        gameBoard = tBoard;
        gamePainter = new GPainter(this, tBoard);
        gameCommand = new Commander(this, gameBoard, gamePainter);
        if (!GraphicsEnvironment.isHeadless()) {
            program = new JFrame("GMeSudoYu");
            program.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            program.setLocation(300, 200);
            fileSelect = new JFileChooser();
            started = false;
            program.setLayout(new BorderLayout());
            program.add(gamePainter, BorderLayout.CENTER);
            JMenuBar menuBar = new JMenuBar();
            JMenu menu;
            JMenuItem jmi;
            menu = new JMenu("File");
            jmi = new JMenuItem("Load");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Save");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Quit");
            jmi.addActionListener(this);
            menu.add(jmi);
            menuBar.add(menu);
            menu = new JMenu("Edit");
            jmi = new JMenuItem("Undo");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Lock");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Unlock");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Reset");
            jmi.addActionListener(this);
            menu.add(jmi);
            menuBar.add(menu);
            menu = new JMenu("Logic");
            jmi = new JMenuItem("Create");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Check");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Analyse");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Solve");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("MiniSolve");
            jmi.addActionListener(this);
            menu.add(jmi);
            menuBar.add(menu);
            menu = new JMenu("Help");
            jmi = new JMenuItem("Playing");
            jmi.setActionCommand("Help");
            jmi.addActionListener(this);
            menu.add(jmi);
            jmi = new JMenuItem("Keys");
            jmi.addActionListener(this);
            menu.add(jmi);
            menuBar.add(menu);
            program.setJMenuBar(menuBar);
            program.pack();
            program.setVisible(true);
            gamePainter.addHierarchyBoundsListener(this);
            gamePainter.init();
            gameCommand.setCand(true);
            gameCommand.doCommand("Keyflip"); // standard keyboard numeric positioning
            program.addKeyListener(this);
            gamePainter.addMouseListener(this);
        }
        gameBoard.setMaxLogic(5);
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#helpMessage()
     */
    public void helpMessage() {
        this
                .infoMsg(
                        "About GMeSudoYu",
                        "Sudoku is a game involving a 9x9 grid of numbers,\n"
                                + "where each 3x3 box, as well as each row and each column,\n"
                                + "must contain all the numbers 1 to 9.\n"
                                + "\n"
                                + "This program generates sudoku puzzles, and provides\n"
                                + "an interface to complete the puzzles. The active cell\n"
                                + "is changed by directional keys (or by clicking with the\n"
                                + "left mouse button, numbers are placed when a number is\n"
                                + "pressed on the keyboard, the current cell is cleared\n"
                                + "by <Space>, and 'G' generates a puzzle.\n"
                                + "\n"
                                + "Any comments/suggestions, please contact me:\n"
                                + "gmesudoyu@gringer.org\n\n");
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#keysMessage()
     */
    public void keysMessage() {
        this.infoMsg("Keys", "A work in progress -- please watch this space");
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#alertMsg(java.lang.String, java.lang.String)
     */
    public void alertMsg(String title, String msg) {
        JOptionPane.showMessageDialog(program, msg, title,
                JOptionPane.WARNING_MESSAGE);

    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#alertMsg(java.lang.String)
     */
    public void alertMsg(String msg) {
        alertMsg("Alert", msg);
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#doUpdate()
     */
    public void doUpdate() {
        if(!GraphicsEnvironment.isHeadless()){
            gamePainter.repaint();
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#getHeight()
     */
    public int getHeight() {
        // this shouldn't really be needed knowledge for the controller
        return (int) gamePainter.getPreferredSize().getHeight();
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#getWidth()
     */
    public int getWidth() {
        // this shouldn't really be needed knowledge for the controller
        return (int) gamePainter.getPreferredSize().getWidth();
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#infoMsg(java.lang.String, java.lang.String)
     */
    public void infoMsg(String title, String msg) {
        JOptionPane.showMessageDialog(program, msg, title,
                JOptionPane.INFORMATION_MESSAGE);
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#loadBoard()
     */
    public void loadBoard() {
        base.Point[] loadPoint = new base.Point[81];
        for (int i = 0; i < 81; i++) {
            loadPoint[i] = new base.Point();
        }
        int retVal = fileSelect.showOpenDialog(null);
        if (retVal == JFileChooser.APPROVE_OPTION) {
            try {
                String fName = fileSelect.getSelectedFile().getCanonicalPath();
                BufferedReader f = new BufferedReader(new FileReader((fName)));
                String nextLine = "";
                int lineNum = 0;
                while (f.ready()) {
                    nextLine = f.readLine();
                    nextLine = nextLine.trim();
                    String[] cells = nextLine.split(",");
                    System.out.println("Cell length for line " + lineNum + ": "
                            + cells.length);
                    if (cells.length <= 9) {
                        for (int i = 0; i < cells.length; i++) {
                            if (!cells[i].equals("")) {
                                loadPoint[lineNum * 9 + i].setBits(cells[i]);
                            }
                        }
                    } else {
                        System.out.println("Error: too many cells on line "
                                + lineNum);
                    }
                    lineNum++;
                }
                f.close();
                // gameBoard.reset(false);
                gameBoard.staticLoad(loadPoint);
                gameCommand.doUpdate(true);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#makeProgress(java.lang.String, java.lang.String[],
     *      int[], base.GlobalVar[], int)
     */
    public void makeProgress(String title, String[] labels, int[] limits,
            GlobalVar[] values, int cancelOptions) {
        // TODO Auto-generated method stub

    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#quit()
     */
    public void quit() {
        this.saveState();
        System.exit(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#recoverDisplay()
     */
    public void recoverDisplay() {
        if(!GraphicsEnvironment.isHeadless()){
            program.requestFocus();
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#saveBoard()
     */
    public void saveBoard() {
        base.Point[] savePoint = new base.Point[81];
        for (int i = 0; i < 81; i++) {
            savePoint[i] = new base.Point();
        }
        String outString = "";
        gameBoard.staticSave(savePoint);
        for (int y = 0; y < 9; y++) {
            for (int x = 0; x < 8; x++) {
                outString = outString + savePoint[y * 9 + x].toFileBitsString()
                        + ",";
            }
            outString = outString + savePoint[y * 9 + 8].toFileBitsString()
                    + "\n";
        }
        int retVal = fileSelect.showSaveDialog(null);
        if (retVal == JFileChooser.APPROVE_OPTION) {
            try {
                String fName = fileSelect.getSelectedFile().getCanonicalPath();
                File newFile = new File(fName);
                if (newFile.exists()) {
                    if (JOptionPane
                            .showConfirmDialog(null, "File Exists:\n" + fName
                                    + "\n" + "do you want to overwrite it?",
                                    "Overwrite confirmation",
                                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                        newFile.delete();
                    }
                }
                newFile = new File(fName);
                if (!newFile.exists()) {
                    newFile.createNewFile();
                    PrintWriter f = new PrintWriter(new BufferedWriter(
                            new FileWriter(newFile)));
                    f.println(outString);
                    f.close();
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    /**
     * Saves the board to a given file name (adding a &quot;.sud&quot;
     * extension). If the file already exists, then it will not be overwritten.
     * 
     * @param fName
     *            File name to save to (without .sud extension)
     */
    public void saveBoard(String fName) {
        base.Point[] savePoint = new base.Point[81];
        for (int i = 0; i < 81; i++) {
            savePoint[i] = new base.Point();
        }
        String outString = "+---+---+---+\n";
        gameBoard.staticSave(savePoint);
        for (int y = 0; y < 9; y++) {
            outString = outString + "|";
            for (int x = 0; x < 9; x++) {
                outString = outString + savePoint[y * 9 + x].toChar();
                if(x % 3 == 2){
                    outString = outString + "|";
                }
            }
            outString = outString + "\n";
            if(y % 3 == 2){
                outString = outString + "+---+---+---+\n";
            }
        }
        File newFile = new File(fName+".sud");
        if (!newFile.exists()) {
            try {
                newFile.createNewFile();
                PrintWriter f = new PrintWriter(new BufferedWriter(
                        new FileWriter(newFile)));
                            f.println(outString);
                        f.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * Saves the state of the game into the settings file.
     */
    public void saveState() {
        SaveResource sr = new SaveResource();
        String[] settings = new String[Commander.SETTINGSSIZE];
        int[] values = new int[Commander.SETTINGSSIZE];
        gameCommand.saveSettings(settings, values);
        File newFile = new File("static.msd");
        if (newFile.exists()) {
            newFile.delete();
            newFile = new File("static.msd");
        }
        if (!newFile.exists()) {
            try {
                newFile.createNewFile();
                BufferedOutputStream f = new BufferedOutputStream(
                        new FileOutputStream(newFile));
                sr.setID(SaveResource.GAMESETTINGS); sr.setData(settings, values);
                f.write(sr.saveData());
                sr.setID(SaveResource.BOARDDATA); sr.setData(this.gameBoard);
                f.write(sr.saveData());
                f.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * Loads the previous state of the game from the settings file. This will
     * not work properly if the settings file is larger than 64kiB. A typical
     * settings file on a desktop is less than 500 bytes, as only one game board
     * plus a few settings are saved.
     */
    public void loadState() {
        SaveResource sr = new SaveResource();
        String[] settings = new String[Commander.SETTINGSSIZE];
        int[] values = new int[Commander.SETTINGSSIZE];
        byte[] tData;
        File newFile = new File("static.msd");
        if (newFile.exists() && newFile.length() < Short.MAX_VALUE) {
            try {
                tData = new byte[Math.min((int)newFile.length(),0xffff)];
                newFile.createNewFile();
                BufferedInputStream f = new BufferedInputStream(
                        new FileInputStream(newFile));
                f.read(tData);
                tData = sr.loadData(tData); sr.getData(settings, values);
                tData = sr.loadData(tData); sr.getData(this.gameBoard);
                f.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            gameCommand.loadSettings(settings, values);
        }
        gameCommand.doUpdate(true);
    }
    /*
     * (non-Javadoc)
     * 
     * @see base.Controller#win()
     */
    public void win() {
    }

    /**
     * Loads up the initial board with a generated puzzle
     */
    public void start() {
        gameCommand.makePuzzle();
        started = true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
     */
    public void keyPressed(KeyEvent e) {
        String keyText = KeyEvent.getKeyText(e.getKeyCode());
        if (keyText.length() > "NumPad-".length()) {
            if (keyText.substring(0, "NumPad-".length()).equals("NumPad-")) {
                keyText = keyText.substring("NumPad-".length());
            }
        }
//        gamePainter.getGraphics().drawString(keyText, 200, 200);
        if ((keyText.compareTo("0") >= 0) && (keyText.compareTo("9") <= 0)) {
            gameCommand.numChange(Integer.parseInt(keyText));
        } else if (keyText.equals("G")) {
            gameCommand.makePuzzle();
        } else if (keyText.equals("Q")) {
            gameCommand.doCommand("Quit");
        } else if (keyText.equals("Left")) {
            gameCommand.changePos(-1, 0);
        } else if (keyText.equals("Right")) {
            gameCommand.changePos(1, 0);
        } else if (keyText.equals("Up")) {
            gameCommand.changePos(0, -1);
        } else if (keyText.equals("Down")) {
            gameCommand.changePos(0, 1);
        } else if (keyText.equals("Space")) {
            gameCommand.doCommand("Clear");
        } else if (keyText.equals("Escape")) {
            gameCommand.doCommand("Quit");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
     */
    public void keyReleased(KeyEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
     */
    public void keyTyped(KeyEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
     */
    public void mouseClicked(MouseEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        gameCommand.doPointerPress(e.getX(), e.getY());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
     */
    public void mouseReleased(MouseEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
     */
    public void mouseEntered(MouseEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
     */
    public void mouseExited(MouseEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
//        System.out.println(e.getActionCommand());
        gameCommand.doCommand(e.getActionCommand());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.HierarchyBoundsListener#ancestorMoved(java.awt.event.HierarchyEvent)
     */
    public void ancestorMoved(HierarchyEvent e) {
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.awt.event.HierarchyBoundsListener#ancestorResized(java.awt.event.HierarchyEvent)
     */
    public void ancestorResized(HierarchyEvent e) {
//        System.out.println("Resized: " + gamePainter.getSize());
        if (this.started) {
            gamePainter.resetSize();
        }
    }
}
