/*
 * Copyright 2005-2008 David Hall (gringer)
 *
 *  This file is part of JMeSudoYu, a Java sudoku Solver/Puzzle generator
 *  with an emphasis on easily portable code for j2me-capable cellphones.
 *
 *  JMeSudoYu is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  JMeSudoYu is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with JMeSudoYu.  If not, see <http://www.gnu.org/licenses/>.
 */
package gmesudoyu;

import base.Painter;
import base.Board;

import javax.swing.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.geom.AffineTransform;

/**
 * Painter class for the graphical (Java) port. This class handles graphical (or
 * board-based) output. It has a fairly strong tie-in with the Board class.
 * 
 * @author gringer
 * 
 */
public class GPainter extends JPanel implements Painter {
	static final long serialVersionUID = 1;

	BufferedImage sudImage;
	GController gamePanel;
	Board gameBoard;
	AffineTransform af;
	Graphics2D easel;
	int boardWidth;
	int boardHeight;
	float xScale;
	float yScale;
    float fontScale;
	int cellWidth;
	int cellHeight;
	int fontWidth;
	int fontHeight;
	boolean drawSideVertical;
	boolean doSideNums;
    static int BESTWIDTH = 396;
    static int BESTHEIGHT = 396;

	/**
     * Constructor for this class. Sets all fields to their default values, and
     * links the class to a Controller and a Board.
     */
    public GPainter(GController tPanel, Board tBoard) {
        super();
        gamePanel = tPanel;
        gameBoard = tBoard;
        boardWidth = GPainter.BESTWIDTH;
        boardHeight = GPainter.BESTHEIGHT;
        cellWidth = boardWidth / 9;
        cellHeight = boardHeight / 9;
        drawSideVertical = true;
        doSideNums = true;
        if (drawSideVertical) {
            boardWidth = cellWidth * 10;
            boardHeight = cellHeight * 9;
        } else {
            boardWidth = cellWidth * 9;
            boardHeight = cellHeight * 10;
        }
        af = null;
    }

	/**
     * Initialises the graphics (called after this is visible)
     */
    public void init() {
        int minBoardDim = Math.min(boardWidth, boardHeight);
        int minBestDim = Math.min(GPainter.BESTWIDTH, GPainter.BESTHEIGHT);
        sudImage = (BufferedImage) (this.createImage(boardWidth, boardHeight));
        easel = (Graphics2D) sudImage.getGraphics();
        fontScale = (float) minBoardDim / (float) minBestDim;
        easel.setFont(new Font(null, Font.BOLD, (int) (20 * fontScale)));
        fontWidth = easel.getFontMetrics().charWidth('X');
        fontHeight = easel.getFontMetrics().getAscent();
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#clearBox(int)
	 */
	public void clearBox(int boxNum) {
        Color oldColor = easel.getColor();
        int bx = boxNum % 3;
        int by = boxNum / 3;
        easel.setColor(easel.getBackground());
        easel.setStroke(new BasicStroke(2.0f));
        easel.drawRect(bx * 3 * cellWidth + 2, by * 3 * cellHeight + 2,
                cellWidth * 3 - 3, cellHeight * 3 - 3);
        easel.setStroke(new BasicStroke());
        easel.setColor(oldColor);
        this.drawSmallLines();
        this.drawBigLines();
	}

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#clearPos(int, int, boolean)
     */
    public void clearPos(int tx, int ty, boolean doCands) {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            easel.setColor(easel.getBackground());
            easel.setStroke(new BasicStroke(2.0f));
            easel.fillRect(tx * cellWidth + 1, ty * cellHeight + 1,
                    cellWidth - 1, cellHeight - 1);
            easel.setStroke(new BasicStroke());
            this.drawBigLines();
            this.drawSideNums();
            drawPos(tx, ty, doCands);
            easel.setColor(oldColor);
        }
    }

    /**
     * Draws the smaller dividing lines (between each cell)
     */
    private void drawSmallLines() {
        Color oldColor = easel.getColor();
        easel.setColor(Color.GRAY);
        for (int x = 0; x < 9; x++) {
            for (int y = 0; y < 9; y++) {
                easel.drawRect(x * cellWidth, y * cellHeight, cellWidth,
                        cellHeight);
            }
        }
        easel.setColor(oldColor);
    }
    
	/**
	 * Draws the larger dividing lines (between each 3x3 group of cells)
	 */
	private void drawBigLines() {
		Color oldColor = easel.getColor();
		easel.setColor(Color.BLACK);
		easel.setStroke(new BasicStroke(3.0f));
		for (int i = 0; i < 3; i++) {
			easel.drawLine(i * cellWidth * 3, 0, i * cellWidth * 3,
					cellHeight * 9 - 2);
			easel.drawLine(0, i * cellHeight * 3, cellWidth * 9 - 2, i
					* cellHeight * 3);
		}
		easel.drawLine(9 * cellWidth - 1, 0, 9 * cellWidth - 1,
				cellHeight * 9 - 2);
		easel.drawLine(0, 9 * cellHeight - 1, cellWidth * 9 - 2,
				9 * cellHeight - 1);
		easel.setStroke(new BasicStroke());
		easel.setColor(oldColor);
	}

	/**
	 * Draws the numbers down the right hand (or bottom) side.
	 */
	private void drawSideNums() {
		if (doSideNums) {
			Color oldColor = easel.getColor();
			easel.setStroke(new BasicStroke(3.0f));
			int xmul = 0;
			int ymul = 0;
			if (drawSideVertical) {
				ymul = 1;
			} else {
				xmul = 1;
			}
			for (int i = 0; i < 9; i++) {
				if (gameBoard.numberComplete(i)) {
					easel.setColor(Color.GRAY);
				} else {
					easel.setColor(Color.GREEN);
				}
				easel.drawString("" + (i + 1), xmul
						* (i * cellWidth + cellWidth / 2 - fontWidth / 2)
						+ ymul
						* (9 * cellWidth + cellWidth / 2 - fontWidth / 2), xmul
						* (9 * cellHeight + cellHeight / 2 + fontHeight / 2)
						+ ymul
						* (i * cellHeight + cellHeight / 2 + fontHeight / 2));
				easel.setColor(Color.GRAY);
				easel.drawRect(ymul * cellWidth * 9 + xmul * cellWidth * i + 2,
						ymul * cellHeight * i + xmul * cellHeight * 9 + 2,
						cellWidth - 4, cellHeight - 4);
			}
			easel.setStroke(new BasicStroke());
			easel.setColor(oldColor);
		}
	}

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawBoard(boolean)
     */
    public void drawBoard(boolean doCands) {
        if (!GraphicsEnvironment.isHeadless()) {
            this.clearScreen();
            for (int x = 0; x < 9; x++) {
                for (int y = 0; y < 9; y++) {
                    this.drawPos(x, y, doCands);
                }
            }
            drawSmallLines();
            drawBigLines();
            drawSideNums();
        }
    }

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawBox(int)
     */
    public void drawBox(int boxNum) {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            int bx = boxNum % 3;
            int by = boxNum / 3;
            easel.setColor(Color.BLUE);
            easel.setStroke(new BasicStroke(2.0f));
            easel.drawRect(bx * 3 * cellWidth + 2, by * 3 * cellHeight + 2,
                    cellWidth * 3 - 3, cellHeight * 3 - 3);
            easel.setStroke(new BasicStroke());
            easel.setColor(oldColor);
        }
    }

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawChoice(int)
     */
	public void drawChoice(int tVal) {
		// TODO Auto-generated method stub

	}

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawPos(int, int, int, boolean, boolean)
     */
    public void drawPos(int pVal, int tx, int ty, boolean doNum, boolean doCands) {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            Composite oldComposite = easel.getComposite();
            drawSquare(tx, ty);
            if (doNum) {
                easel.setColor(Color.GRAY);
                easel.setComposite(AlphaComposite.getInstance(
                        AlphaComposite.SRC_OVER, 0.7f));
                easel.drawString(Integer.toString(pVal), cellWidth * tx
                        + (cellWidth / 2) - (fontWidth / 2), cellHeight * ty
                        + (cellWidth / 2) + (fontHeight / 2) - 2);
                easel.setComposite(oldComposite);
            }
            drawPos(tx, ty, doCands);
            easel.setColor(oldColor);
        }
    }

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawSquare(int, int)
     */
    public void drawSquare(int tx, int ty) {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            easel.setColor(Color.BLUE);
            easel.setStroke(new BasicStroke(2.0f));
            easel.drawRect(tx * cellWidth + 2, ty * cellHeight + 2,
                    cellWidth - 3, cellHeight - 3);
            easel.setStroke(new BasicStroke());
            easel.setColor(oldColor);
        }
    }

	public Dimension getPreferredSize() {
		return new Dimension(boardWidth, boardHeight);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#getFontHeight()
	 */
	public int getFontHeight() {
		return fontHeight;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#setSize(int, int, int, int)
	 */
	public void setSize(int tsw, int tsh, int tpx, int tpy) {
		// TODO Auto-generated method stub

	}

	/**
     * Updates size to current size. For small sizes (< BESTWIDTH/HEIGHT
     * pixels), apply transform. For larger sizes, modify font size. For some
     * reason, it is possible to jiggle the resizing when smaller than the
     * BESTWIDTH/HEIGHT in such a way that larger sizes use the transform,
     * rather than changing the font size (which is not desired).
     */
    public void resetSize() {
        if (!GraphicsEnvironment.isHeadless()) {
            if ((this.getWidth() < GPainter.BESTWIDTH)
                    || (this.getHeight() < GPainter.BESTHEIGHT)) {
                boardWidth = GPainter.BESTWIDTH;
                boardHeight = GPainter.BESTHEIGHT;
                cellWidth = boardWidth / 9;
                cellHeight = boardHeight / 9;
                drawSideVertical = (this.getWidth() >= this.getHeight());
                if (drawSideVertical) {
                    boardWidth = (boardWidth * 10) / 9;
                } else {
                    boardHeight = (boardHeight * 10) / 9;
                }
                this.init();
                this.xScale = (float) Math.min(this.getWidth(), this
                        .getHeight())
                        / (float) boardWidth;
                this.yScale = xScale;
                this.af = AffineTransform.getScaleInstance(this.xScale,
                        this.yScale);
            } else {
                drawSideVertical = (boardWidth >= boardHeight);
                if (drawSideVertical) {
                    boardWidth = (this.getSize().width * 9) / 10;
                    boardHeight = this.getSize().height;
                } else {
                    boardWidth = this.getSize().width;
                    boardHeight = (this.getSize().height * 9) / 10;
                }
                cellWidth = boardWidth / 9;
                cellHeight = boardHeight / 9;
                if (drawSideVertical) {
                    boardWidth = cellWidth * 10;
                    boardHeight = cellHeight * 9;
                } else {
                    boardWidth = cellWidth * 9;
                    boardHeight = cellHeight * 10;
                }
                easel.dispose();
                this.init();
            }
            this.drawBoard(true);
        }
    }

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#startUpdate()
     */
	public void startUpdate() {
		// TODO Auto-generated method stub

	}

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#stopUpdate()
     */
	public void stopUpdate() {
		// TODO Auto-generated method stub

	}

	/**
     * Erases all graphics (without creating a new image buffer)
     */
    private void clearScreen() {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            easel.setColor(this.getBackground());
            easel.fillRect(0, 0, this.getWidth(), this.getHeight());
            easel.setColor(oldColor);
        }
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
        g2.drawImage(sudImage, af, null);
	}

	/*
     * (non-Javadoc)
     * 
     * @see base.Painter#drawPos(int, int, boolean)
     */
    public void drawPos(int tx, int ty, boolean doCands) {
        if (!GraphicsEnvironment.isHeadless()) {
            Color oldColor = easel.getColor();
            base.Point p = gameBoard.getPoint(tx, ty);
            if (p.getLocked()) {
                easel.setColor(Color.BLACK);
            } else if (p.getError()) {
                easel.setColor(Color.RED);
            } else {
                easel.setColor(Color.BLUE);
            }
            if (doCands && (p.countBits() > 1) && (p.countBits() < 9)) {
                Font oldFont = easel.getFont();
                easel.setFont(new Font(null, Font.PLAIN,
                        (int) (9 * this.fontScale)));
                int xadj = easel.getFontMetrics().charWidth('X');
                int yadj = easel.getFontMetrics().getAscent() + 3;
                int pVal = p.getValue();
                for (int y = 0; y < 3; y++) {
                    for (int x = 0; x < 3; x++) {
                        int tVal = (x * 3 + y);
                        if ((pVal & (1 << tVal)) != 0) {
                            easel.drawString("" + (tVal + 1), tx * cellWidth
                                    + y * (cellWidth / 3) + xadj, ty
                                    * cellHeight + x * (cellHeight / 3) + yadj);
                        }
                    }
                }
                easel.setFont(oldFont);
            }
            easel.drawString(p.toString(), tx * cellWidth + cellWidth / 2
                    - fontWidth / 2, ty * cellHeight + cellHeight / 2
                    + fontHeight / 2);
            easel.setColor(oldColor);
        }
    }

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#pos2cellX(int)
	 */
	public int pos2cellX(int tx) {
        if(af != null){
            tx = (int)(tx / xScale);
        }
		if (tx >= cellWidth * 9) {
			if (drawSideVertical && (tx >= cellWidth * 10)) {
				tx = cellWidth * 10 - 1;
			} else if (!drawSideVertical) {
				tx = cellWidth * 9 - 1;
			}
		}
		return tx / cellWidth;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#pos2cellY(int)
	 */
	public int pos2cellY(int ty) {
        if(af != null){
            ty = (int)(ty / yScale);
        }
		if (ty >= cellHeight * 9) {
			if (!drawSideVertical && (ty >= cellHeight * 10)) {
				ty = cellHeight * 10 - 1;
			} else if (drawSideVertical) {
				ty = cellHeight * 9 - 1;
			}
		}
		return ty / cellHeight;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#getVertical()
	 */
	public boolean getVertical() {
		return drawSideVertical;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see base.Painter#setVertical(boolean)
	 */
	public void setVertical(boolean tVert) {
		drawSideVertical = tVert;
	}
}
