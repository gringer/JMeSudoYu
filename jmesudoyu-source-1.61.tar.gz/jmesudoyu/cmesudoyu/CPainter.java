/*
 * Copyright 2007-2008 David Hall (gringer)
 *
 *  This file is part of JMeSudoYu, a Java sudoku Solver/Puzzle generator
 *  with an emphasis on easily portable code for j2me-capable cellphones.
 *
 *  JMeSudoYu is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  JMeSudoYu is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with JMeSudoYu.  If not, see <http://www.gnu.org/licenses/>.
 */
package cmesudoyu;

import base.Board;
import base.GlobalVar;
import base.Painter;
import base.Point;

import charvax.swing.*;
import charva.awt.*;

/**
 * @author gringer
 *
 */
/**
 * @author gringer
 *
 */
public class CPainter implements Painter{

   /**
    * Constructor for this class. Sets all fields to their default values, and
    * links the class to a Controller and a Board.
    */
   GlobalVar v0,v1;
   CController gamePanel;
   Board gameBoard;
   JTextArea gameBoardDisplay;
   Toolkit virtTerm;
   int boardX, boardY;
   int fontAttribs;
   int colourAttribs;
   public CPainter(CController tPanel, Board tBoard) {
      super();
      gamePanel = tPanel;
      gameBoard = tBoard;
      // just in case update gets called on them
      v0 = new GlobalVar();
      v1 = new GlobalVar();
      virtTerm = Toolkit.getDefaultToolkit();
      boardX = 4;
      boardY = 4;
      fontAttribs = Toolkit.A_NORMAL;
      setColour(Color.white,Color.black);
   }
   /* (non-Javadoc)
    * @see base.Painter#clearBox(int)
    */
   public void clearBox(int boxNum) {
      // Not used in console version
   }

   /* (non-Javadoc)
    * @see base.Painter#clearPos(int, int, boolean)
    */
   public void clearPos(int tx, int ty, boolean doCands) {
      textXY(" ",boardX+tx+tx/3, boardY-3);
      textXY(" ",boardX-3, boardY+ty+ty/3);
      textXY("         ",boardX+10,boardY+13);
      textXY(" ", boardX+tx+tx/3, boardY+ty+ty/3);
      drawPos(tx,ty,doCands);
   }
   /* (non-Javadoc)
    * @see base.Painter#drawBoard(boolean)
    */
   public void drawBoard(boolean doCands) {
      /* Will generate something like the following:
       * +---+---+---+
       * |74 |  1|   |
       * | 25|   |4 7|
       * |   |   | 8 |
       * +---+---+---+
       * |4  | 36|2  |
       * |  2| 7 |6  |
       * |5 7|9 4|   |
       * +---+---+---+
       * |67 |5 3|9 8|
       * |   |  8|   |
       * |   |4 7|   |
       * +---+---+---+
       */
      this.clearScreen();
      setColour(Color.white,Color.black);
      for (int lineArea = 0; lineArea < 3; lineArea++){
         textXY("+---+---+---+",boardX-1,boardY+lineArea*4-1);
         for (int line = 0; line < 3; line++){
            String num1 = String.valueOf((char)(("a".getBytes()[0])+lineArea*3+line));
            String num2 = String.valueOf((char)(("j".getBytes()[0])+lineArea*3+line));
            textXY(num1,boardX+lineArea*4+line,boardY-2);
            textXY(num2,boardX-2,boardY+lineArea*4+line);
            for (int colArea = 0; colArea < 3; colArea++){
               textXY("|",boardX+colArea*4-1,boardY+lineArea*4+line);
               for (int col = 0; col < 3; col++){
                  drawPos(colArea*3+col, lineArea*3+line, doCands);
               }
            }
            textXY("|",boardX+11,boardY+lineArea*4+line);
         }
      }
      textXY("+---+---+---+",boardX-1,boardY+11);
      textXY("Candidates:", boardX-2,boardY+13);
      textXY("CMeSudoYu>", boardX-2,boardY+15);
      if(gamePanel.getCommandMode()){
         textXY("[Command Mode (/?cklmorstuvx)]            ", boardX-2,boardY+16);
      }
      else{
         textXY("[Type '?' for help, '/' for Command Mode]", boardX-2,boardY+16);
      }
   }

   /* (non-Javadoc)
    * @see base.Painter#drawBox(int)
    */
   public void drawBox(int boxNum) {
      // Not used in console version
   }

   /* (non-Javadoc)
    * @see base.Painter#drawChoice(int)
    */
   public void drawChoice(int tVal) {
      // Not used in console version
   }

   /* (non-Javadoc)
    * @see base.Painter#drawPos(int, int, int, boolean, boolean)
    */
   public void drawPos(int pVal, int tx, int ty, boolean doNum, boolean doCands) {
      clearPos(tx, ty, doCands);
      textXY("*",boardX+tx+tx/3,boardY-3);
      textXY("*",boardX-3,boardY+ty+ty/3);
   }

   /* (non-Javadoc)
    * @see base.Painter#drawSquare(int, int)
    */
   public void drawSquare(int tx, int ty) {
      // Not used in console version

   }

   /* (non-Javadoc)
    * @see base.Painter#getFontHeight()
    */
   public int getFontHeight() {
      // Not used in console version
      return 0;
   }

   /* (non-Javadoc)
    * @see base.Painter#setSize(int, int, int, int)
    */
   public void setSize(int tsw, int tsh, int tpx, int tpy) {
      // Not used in console version

   }

   /* (non-Javadoc)
    * @see base.Painter#startUpdate()
    */
   public void startUpdate() {
      // Not (currently) used in console version -- update is quick

   }

   /* (non-Javadoc)
    * @see base.Painter#stopUpdate()
    */
   public void stopUpdate() {
      // Not (currently) used in console version -- update is quick

   }
   /**
    * Attempts to clear the screen
    */
   public void clearScreen() {
      charva.awt.Point oldCursor = virtTerm.getCursor();
      virtTerm.clear();
      virtTerm.setCursor(oldCursor);
   }
   /**
    * Causes the computer to beep
    */
   public void beep(){
      virtTerm.beep();
   }
   /**
    * Sets the draw colour 
    * @param foreground Foreground colour to be set
    * @param background Background colour to be set
    */
   private void setColour(Color foreground, Color background){
      ColorPair tempCP = new ColorPair(foreground,background);
      try {
         colourAttribs = virtTerm.getColorPairIndex(tempCP);
      } catch (TerminfoCapabilityException e) {
         e.printStackTrace();
      }
   }
   /* (non-Javadoc)
    * @see base.Painter#drawPos(int, int, boolean)
    */
   public void drawPos(int tx, int ty, boolean doCands) {
      int oldAttribs = this.fontAttribs;
      Point p = gameBoard.getPoint(tx, ty);
      if(p.getLocked()){
         this.fontAttribs = Toolkit.A_BOLD;
         setColour(Color.white,Color.black);
      }
      else{
         if(p.getError()){
            this.fontAttribs = Toolkit.A_BOLD;
            setColour(Color.red,Color.black);
         }
         else{
            this.fontAttribs = Toolkit.A_NORMAL;
            setColour(Color.white,Color.black);
         }
      }
      if (doCands && ((p.countBits() > 1) && (p.countBits() < 9))){
         textXY(".", boardX+tx+tx/3,
               boardY+ty+ty/3);
      }
      else {
         textXY(p.toString(), boardX+tx+tx/3,
               boardY+ty+ty/3);
      }
      if(doCands){
         for(int i=0; i<9; i++){
            if((p.getValue() & 1<<i) != 0){
               textXY(""+(i+1),boardX+i+10,boardY+13);
            }
         }
      }
      this.fontAttribs = oldAttribs;
   }
   /**
    * Writes a text to an X,Y location 
    * @param writeText text to write to the screen
    * @param x X location for writing
    * @param y Y location for writing
    */
   private void textXY(String writeText, int x, int y){
      charva.awt.Point oldCursor = virtTerm.getCursor();
      virtTerm.setCursor(x,y);
      virtTerm.addString(writeText, this.fontAttribs, this.colourAttribs);
      virtTerm.setCursor(oldCursor);
   }
   /* (non-Javadoc)
    * @see base.Painter#pos2cellX(int)
    */
   public int pos2cellX(int tx){
      return tx;
   }
   /* (non-Javadoc)
    * @see base.Painter#pos2cellY(int)
    */
   public int pos2cellY(int ty){
      return ty;
   }
   /* (non-Javadoc)
    * @see base.Painter#getVertical()
    */
   public boolean getVertical(){
      return true;
   }
   /* (non-Javadoc)
    * @see base.Painter#setVertical(boolean)
    */
   public void setVertical(boolean tVert){}
}
