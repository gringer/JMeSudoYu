/*
 * Copyright 2007-2008 David Hall (gringer)
 *
 *  This file is part of JMeSudoYu, a Java sudoku Solver/Puzzle generator
 *  with an emphasis on easily portable code for j2me-capable cellphones.
 *
 *  JMeSudoYu is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  JMeSudoYu is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with JMeSudoYu.  If not, see <http://www.gnu.org/licenses/>.
 */
package cmesudoyu;

import base.Commander;
import base.Controller;
import base.GlobalVar;
import base.Board;

import charva.awt.event.*;
import charvax.swing.*;
import charva.awt.*;


/**
 * @author gringer
 *
 */
public class CController extends JFrame implements Controller, ActionListener, KeyListener {
   Board gameBoard;
   CPainter gamePainter;
   Commander gameCommand;
   JTextField inputarea; // dummy to allow program to work
   JDialog messageDialog;
   boolean commandMode;
   boolean inDialog;
   public CController(Board tBoard) {
      super(" ");
      gameBoard = tBoard;
      gamePainter = new CPainter(this, tBoard);
      gameCommand = new Commander(this, gameBoard, gamePainter);
      gameCommand.setCand(true);
      commandMode = false;
      inputarea = new JTextField();
      inputarea.setColumns(0);
      inputarea.setLocation(13, 19);
      this.setLayout(null);
      this.getContentPane().add(inputarea);
      //inputarea.setEditable(false);
      messageDialog = new JDialog();
      messageDialog.setLocation(1,1);
      this.getContentPane().add(messageDialog);
      //pack();
      //this.setSize(60,25);
      this.show();
      this.addKeyListener(this);
      this.getContentPane().setForeground(Color.red);
      //this.setBackground(Color.blue);
      inDialog = false;
   }

   /* (non-Javadoc)
    * @see base.Controller#alertMsg(java.lang.String, java.lang.String)
    */
   public void alertMsg(String title, String msg) {
      // Not used (yet) in console version

   }

   /* (non-Javadoc)
    * @see base.Controller#alertMsg(java.lang.String)
    */
   public void alertMsg(String msg) {
      // Not used (yet) in console version

   }

   /* (non-Javadoc)
    * @see base.Controller#doUpdate()
    */
   public void doUpdate() {
      // Not needed in console version -- painting is quick

   }

   /* (non-Javadoc)
    * @see base.Controller#getHeight()
    */
   public int getHeight() {
      // Not used (yet) in console version -- screen height is fixed
      return 0;
   }

   /* (non-Javadoc)
    * @see base.Controller#getWidth()
    */
   public int getWidth() {
      // Not used (yet) in console version -- screen width is fixed
      return 0;
   }

   /* (non-Javadoc)
    * @see base.Controller#helpMessage()
    */
   public void helpMessage() {
      this.infoMsg("Help",
            "Sudoku is a game involving a 9x9 grid of numbers, "
            + "where each 3x3 box, as well as each row and each column, "
            + "must contain all the numbers 1 to 9.\n"
            + "\n"
            + "This program generates sudoku puzzles, and provides "
            + "an interface to complete the puzzles. The active cell "
            + "is changed by typing letters 'a' to 'r', candidate "
            + "numbers are set and cleared by typing '1' to '9', and "
            + "the current cell is cleared by typing '0'.\n"
            + "\n"
            + "type 'x' to exit, or '/k' (slash followed by 'k') for " 
            + "more keys.\n"
            + "\n"
            + "Any comments/suggestions, please contact me: "
            + "jmesudoyu@gringer.dis.org.nz");
      gameCommand.doUpdate(true);
   }
   /* (non-Javadoc)
    * @see base.Controller#keysMessage()
    */
   public void keysMessage(){
      this.infoMsg("Keys",
            "A command mode is also avaliable by typing '/'. The following " +
            "commands are possible in this mode:\n\n" +
            "/: Leave command mode\n" +
            "?: Help\n" +
            "(c)heck : Work out if the puzzle can be solved\n" +
            "e(x)it : exits from the game\n" +
            "(k)eys : This screen\n" +
            "(l)oad : Do nothing\n" +
            "(m)ini-solve : Apply simple logic to the board\n" +
            "l(o)ck : Lock single candidate locations\n" +
            "(r)eset : Clear the board at all unlocked locations\n" +
            "(s)ave : Do nothing\n" +
            "crea(t)e : Generates a new puzzle\n" +
            "(u)nlock : Remove locking from the board\n" +
            "sol(v)e : Attempt to solve the board using known logic\n" +
            "\n" +
            "Additionally, pressing <Esc> exits, and <Backspace> " +
            "will (in most cases) undo the last operation."
            );
   }
   /* (non-Javadoc)
    * @see base.Controller#infoMsg(java.lang.String, java.lang.String)
    */
   public void infoMsg(String title, String msg) {
      inDialog = true;
      JTextArea textArea = new JTextArea(msg);
      textArea.setEditable(false);
      textArea.setLineWrap(true);
      textArea.setWrapStyleWord(true);
      textArea.setLocation(4,4);
      textArea.setColumns(60);
      textArea.setRows(20);
      textArea.setEnabled(false);
      messageDialog.add(textArea,BorderLayout.NORTH);
      JButton okButton = new JButton("Ok");
      okButton.addActionListener(this);
      okButton.setActionCommand("Ok");
      messageDialog.add(okButton,BorderLayout.SOUTH);
      messageDialog.pack();
      messageDialog.show();
      gameCommand.doUpdate(true);
   }

   /* (non-Javadoc)
    * @see base.Controller#loadBoard()
    */
   public void loadBoard() {
      // TODO Auto-generated method stub
      
   }

   /* (non-Javadoc)
    * @see base.Controller#makeProgress(java.lang.String, java.lang.String[], int[], base.GlobalVar[], int)
    */
   public void makeProgress(String title, String[] labels, int[] limits,
         GlobalVar[] values, int cancelOptions) {
      // Not used in console version -- Puzzle generation is quick

   }

   /* (non-Javadoc)
    * @see base.Controller#quit()
    */
   public void quit() {
      System.exit(0);
   }

   /* (non-Javadoc)
    * @see base.Controller#recoverDisplay()
    */
   public void recoverDisplay() {
      // Not used in console version -- game always has the focus

   }

   /* (non-Javadoc)
    * @see base.Controller#saveBoard()
    */
   public void saveBoard() {
      // TODO Auto-generated method stub

   }

   /* (non-Javadoc)
    * @see base.Controller#win()
    */
   public void win() {
      gamePainter.beep();
   }
   /**
    * Begins the console controller
    */
   public void start() {
      gameCommand.makePuzzle();
   }
   /* (non-Javadoc)
    * @see charva.awt.event.ActionListener#actionPerformed(charva.awt.event.ActionEvent)
    */
   public void actionPerformed(ActionEvent e)
   {   
      String action = e.getActionCommand();
      if (action.equals("Exit")) {
         gameCommand.doCommand("Quit");
      }
      else if(action.equals("Ok")){
         messageDialog.hide();
         inDialog = false;
         this.setFocus(inputarea);
      }
   }

   /* (non-Javadoc)
    * @see charva.awt.event.KeyListener#keyPressed(charva.awt.event.KeyEvent)
    */
   public void keyPressed(KeyEvent e) {
      if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE){
         gameCommand.doCommand("Undo");
      }
      if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
         gameCommand.doCommand("Quit");
      }
   }

   /* (non-Javadoc)
    * @see charva.awt.event.KeyListener#keyReleased(charva.awt.event.KeyEvent)
    */
   public void keyReleased(KeyEvent e) {
      // Not used (yet)
   }

   /* (non-Javadoc)
    * @see charva.awt.event.KeyListener#keyTyped(charva.awt.event.KeyEvent)
    */
   public void keyTyped(KeyEvent e) {
      if(e.getKeyChar() == 'x'){
         gameCommand.doCommand("Quit");
      }
      else if(e.getKeyChar() == '?'){
         gameCommand.doCommand("Help");
      }
      if(commandMode){
         if (e.getKeyChar() == 'c'){
            gameCommand.doCommand("Check");
         }
         else if (e.getKeyChar() == 'k'){
            gameCommand.doCommand("Keys");
         }
         else if (e.getKeyChar() == 'l'){
            gameCommand.doCommand("Load");
         }
         else if(e.getKeyChar() == 'm'){
            gameCommand.doCommand("MiniSolve");
         }
         else if (e.getKeyChar() == 'o'){
            gameCommand.doCommand("Lock");
         }
         else if (e.getKeyChar() == 'r'){
            gameCommand.doCommand("Reset");
         }
         else if (e.getKeyChar() == 's'){
            gameCommand.doCommand("Save");
         }
         else if (e.getKeyChar() == 't'){
            gameCommand.doCommand("Create");
         }
         else if (e.getKeyChar() == 'u'){
            gameCommand.doCommand("Unlock");
         }
         else if (e.getKeyChar() == 'v'){
            gameCommand.doCommand("Solve");
         }
         commandMode = false;
         gameCommand.doUpdate(true);
      }
      else{
         if(e.getKeyChar() >= 'a' && e.getKeyChar() <= 'r'){
            if(e.getKeyChar() < 'j'){
               gameCommand.setXPos(e.getKeyChar() - 'a');
            }
            else{
               gameCommand.setYPos(e.getKeyChar() - 'j');
            }
         }
         else if(e.getKeyChar() == '0'){ // clear location
            gameCommand.doButton(Controller.LEFT);
         }
         else if(e.getKeyChar() >= '1' && e.getKeyChar() <= '9'){
            gameCommand.numChange(e.getKeyChar() - '0');
         }
         else if(e.getKeyChar() == '/'){
            commandMode = true;
            gameCommand.doUpdate(true);
         }
         //inputarea.setText("");
      }
   }
   /**
    * Retrieves the current command mode ('/') state of the program
    * @return whether or not the program is in command mode
    */
   public boolean getCommandMode(){
         return commandMode;
   }
   /**
    * Retrieves the current dialog state of the program
    * @return whether or not the program is currently displaying a dialog
    */
   public boolean getDialogMode(){
      return inDialog;
   }
}